import React from 'react';
import { useParams } from 'react-router';

const Param = (props) => {
    const { param } = useParams();
    const { color1 } = useParams();
    const { color2 } = useParams();
    return (
    <div style={{ 
        color: color1, 
        backgroundColor: color2,
        height: 150,
        textAlign: 'center',
        fontSize: 50
     }}>
        The {isNaN(parseInt(param)) ? 'word' : 'number'} is { param }.
    </div>

    )
    // const num = parseInt(number)

    // if(isNaN(num)) {
    //     return (
    //         <h1>The word is { number }.</h1>
    //     );
    // } else {
    //     return (
    //         <h1>The number is {number} </h1>
    //     )
    // }

}

export default Param;
import React from 'react';

const Home = (props) => {
    return (
        <h1 style={{
            fontWeight: 400, 
            textAlign:'center'
        }}>
            Welcome
        </h1>
    )
}

export default Home;